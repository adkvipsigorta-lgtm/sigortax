import{z as e,aF as r,al as t}from"./BameSCd4.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
