import{e,n,o as t,c as a}from"./BameSCd4.js";const i=e({__name:"guvenlik",setup(o){return n("/settings#guvenlik",{replace:!0}),(r,s)=>(t(),a("div"))}});export{i as default};
