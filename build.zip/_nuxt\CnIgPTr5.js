import{e,n as a,o as t,c as n}from"./BameSCd4.js";const p=e({__name:"index",setup(r){return a("/araclar/mutabakat",{replace:!0}),(o,c)=>(t(),n("div"))}});export{p as default};
