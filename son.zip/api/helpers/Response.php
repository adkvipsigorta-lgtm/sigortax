<?php

class Response
{
    public static function json($data, int $status = 200): void
    {
        http_response_code($status);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function success($data = null, string $message = 'OK', int $status = 200): void
    {
        self::json(['success' => true, 'message' => $message, 'data' => $data], $status);
    }

    public static function error(string $message, int $status = 400, $errors = null): void
    {
        $response = ['success' => false, 'message' => $message];
        if ($errors !== null) {
            $response['errors'] = $errors;
        }
        self::json($response, $status);
    }

    public static function paginated(array $result): void
    {
        self::json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => $result['pagination'],
        ]);
    }

    public static function csv(array $rows, array $columns, string $filename): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"$filename\"");
        echo "\xEF\xBB\xBF"; // UTF-8 BOM

        $out = fopen('php://output', 'w');
        fputcsv($out, array_column($columns, 'label'), ';');

        foreach ($rows as $row) {
            $line = [];
            foreach ($columns as $col) {
                $val = $row[$col['key']] ?? '';
                $line[] = $val;
            }
            fputcsv($out, $line, ';');
        }

        fclose($out);
        exit;
    }

    public static function excel(array $rows, array $columns, string $filename, ?string $title = null): void
    {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header('Cache-Control: max-age=0');

        echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        echo '<head><meta charset="utf-8">';
        echo '<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
        echo '<x:Name>Sayfa1</x:Name><x:WorksheetOptions><x:Selected/></x:WorksheetOptions>';
        echo '</x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->';
        echo '<style>';
        echo 'table { border-collapse: collapse; width: 100%; }';
        echo 'th { background-color: #4472C4; color: #FFFFFF; font-weight: bold; padding: 8px 12px; border: 1px solid #2F5496; text-align: left; }';
        echo 'td { padding: 6px 12px; border: 1px solid #D6DCE4; white-space: nowrap; }';
        echo 'tr:nth-child(even) td { background-color: #D9E2F3; }';
        echo '.title { font-size: 16px; font-weight: bold; padding: 10px 0; }';
        echo '.total td { background-color: #E2EFDA !important; font-weight: bold; border-top: 2px solid #4472C4; }';
        echo '.txt { mso-number-format:"\@"; }';
        echo '</style>';
        echo '</head><body>';

        if ($title) {
            echo '<p class="title">' . htmlspecialchars($title) . '</p>';
        }

        echo '<table>';
        echo '<tr>';
        foreach ($columns as $col) {
            echo '<th>' . htmlspecialchars($col['label']) . '</th>';
        }
        echo '</tr>';

        $lastIndex = count($rows) - 1;
        foreach ($rows as $i => $row) {
            $isTotal = ($i === $lastIndex && ($row[$columns[3]['key'] ?? ''] ?? '') === 'TOPLAM');
            echo '<tr' . ($isTotal ? ' class="total"' : '') . '>';
            foreach ($columns as $col) {
                $val = $row[$col['key']] ?? '';
                if (!empty($col['text']) && $val !== '') {
                    echo '<td style="mso-number-format:\'\\@\'">' . htmlspecialchars((string) $val) . '</td>';
                } else {
                    echo '<td>' . htmlspecialchars((string) $val) . '</td>';
                }
            }
            echo '</tr>';
        }

        echo '</table></body></html>';
        exit;
    }
}
