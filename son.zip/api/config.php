<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'crm');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('JWT_SECRET', 'sigorta-crm-secret-key-change-in-production');
define('JWT_EXPIRY', 86400 * 7); // 7 days

define('SOCKET_JWT_SECRET', 'S0ck3t!SigortaCRM#2024xRealtimeKey');
define('SOCKET_API_SECRET', 'socket_api_secret_2024');
define('SOCKET_URL', 'https://sigorta-socket.onrender.com');

define('ITEMS_PER_PAGE', 20);

// Uzaktan guncelleme: GitHub Releases ile
define('UPDATE_GITHUB_REPO', 'hostingci57-ai/sigortax');
// Release'e yuklenecek ZIP asset dosya adi
define('UPDATE_GITHUB_ASSET', 'build.zip');
// Fine-grained PAT (sadece bu repoya erisimi olan). Olustur: https://github.com/settings/tokens?type=beta
define('UPDATE_GITHUB_TOKEN', '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');
// Son kac backup saklansin
define('UPDATE_BACKUP_KEEP', 3);

