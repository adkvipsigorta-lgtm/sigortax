<template>
  <div class="space-y-4">
    <!-- Header -->
    <div class="flex items-center justify-between">
      <h1 class="text-xl font-bold">Günlük Aktivite</h1>
    </div>

    <!-- Filters -->
    <UCard>
      <div class="flex flex-wrap items-center gap-3">
        <!-- Date picker -->
        <div class="flex items-center gap-1 border border-default rounded-lg px-3 py-1.5">
          <UButton icon="i-lucide-chevron-left" size="xs" color="neutral" variant="ghost" @click="prevDay" />
          <input
            v-model="selectedDate"
            type="date"
            class="text-sm font-medium bg-transparent border-0 outline-none cursor-pointer"
            @change="fetch"
          />
          <UButton icon="i-lucide-chevron-right" size="xs" color="neutral" variant="ghost" @click="nextDay" />
        </div>
        <!-- Bugün butonu -->
        <UButton size="sm" color="neutral" variant="outline" @click="goToday">Bugün</UButton>
        <!-- Temsilci filtresi -->
        <USelect
          v-if="isAdmin"
          v-model="filterSoldBy"
          :items="[{ label: 'Tüm Temsilciler', value: 'all' }, ...userOptions]"
          class="w-48"
          size="sm"
          @change="fetch"
        />
      </div>
    </UCard>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
      <!-- Poliçe -->
      <UCard :ui="{ body: 'p-5' }" class="hidden sm:block">
        <p class="text-xs font-semibold tracking-widest uppercase text-muted mb-3">Toplam Poliçe</p>
        <p class="text-4xl font-bold tabular-nums">{{ policies.length }}</p>
      </UCard>

      <!-- Prim Özeti -->
      <UCard :ui="{ body: 'p-5' }">
        <p class="text-xs font-semibold tracking-widest uppercase text-muted mb-3">Prim Özeti</p>
        <div class="flex flex-col gap-1.5 sm:grid sm:grid-cols-3 sm:gap-2">
          <div class="flex items-center justify-between sm:block">
            <p class="text-[10px] text-muted sm:mb-1">Brüt Prim</p>
            <p class="text-sm sm:text-base font-bold text-green-600 tabular-nums leading-tight">{{ formatCurrency(totalGross) }}</p>
          </div>
          <div class="flex items-center justify-between sm:block">
            <p class="text-[10px] text-muted sm:mb-1">Net Prim</p>
            <p class="text-sm sm:text-base font-semibold tabular-nums leading-tight">{{ formatCurrency(totalNet) }}</p>
          </div>
          <div class="flex items-center justify-between sm:block">
            <p class="text-[10px] text-muted sm:mb-1">K</p>
            <p class="text-sm sm:text-base font-semibold text-blue-600 tabular-nums leading-tight">{{ totalCommission ? formatCurrency(totalCommission) : '—' }}</p>
          </div>
        </div>
      </UCard>

      <!-- Eksik Alan -->
      <UCard :ui="{ body: 'p-5' }" class="hidden sm:block">
        <p class="text-xs font-semibold tracking-widest uppercase text-muted mb-3">Eksik Alan</p>
        <p class="text-4xl font-bold tabular-nums" :class="missing > 0 ? 'text-orange-500' : 'text-green-600'">{{ missing }}</p>
      </UCard>
    </div>

    <!-- Table -->
    <UCard :ui="{ body: 'p-0' }">
      <SkeletonTable v-if="loading" :columns="12" />

      <div v-else-if="policies.length === 0" class="text-center py-12 text-muted">
        <UIcon name="i-lucide-inbox" class="size-8 mx-auto mb-2" />
        <p class="text-sm">Bu tarihte poliçe bulunamadı.</p>
      </div>

      <div v-else>
        <table class="w-full text-xs table-fixed">
          <thead class="bg-gray-50 dark:bg-gray-800/50 sticky top-0 z-10">
            <tr>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left">Sigortalı</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left hidden lg:table-cell">Şirket / Poliçe No</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left">Ürün</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left hidden md:table-cell">Üretim</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left hidden md:table-cell">Satış Yapan</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-right">Prim</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left hidden md:table-cell">İş Türü</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-left hidden md:table-cell">Kaynak</th>
              <th class="py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 text-center w-16">Durum</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="p in policies"
              :key="p.id"
              class="border-b border-default hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors"
              :class="isMissing(p) ? 'bg-orange-50/50 dark:bg-orange-900/10' : ''"
            >
              <!-- Sigortalı + TC + Plaka -->
              <td class="py-2.5 px-3 overflow-hidden">
                <NuxtLink v-if="p.customerId" :to="`/musteriler/${p.customerId}`" class="font-semibold text-primary hover:underline block overflow-hidden whitespace-nowrap" style="text-overflow:clip" :title="p.customerName || p.insuredName">
                  {{ p.customerName || p.insuredName || '-' }}
                </NuxtLink>
                <span v-else class="font-semibold block overflow-hidden whitespace-nowrap" style="text-overflow:clip">{{ p.insuredName || '-' }}</span>
                <div class="text-muted mt-0.5">{{ p.customerIdentity }}</div>
                <div v-if="p.plateNo" class="text-muted font-mono">{{ p.plateNo }}</div>
              </td>

              <!-- Şirket + Poliçe No -->
              <td class="py-2.5 px-3 hidden lg:table-cell overflow-hidden">
                <span class="block text-muted overflow-hidden whitespace-nowrap" style="text-overflow:clip">{{ p.companyName }}</span>
                <span class="font-mono text-muted overflow-hidden whitespace-nowrap block" style="text-overflow:clip">{{ p.policyNo }}</span>
              </td>

              <!-- Ürün -->
              <td class="py-2.5 px-3 overflow-hidden">
                <span class="block font-medium overflow-hidden whitespace-nowrap" style="text-overflow:clip" :title="p.insuranceName">{{ p.insuranceName }}</span>
                <div class="text-muted mt-0.5">
                  {{ formatDateShort(p.startsAt) }} → {{ formatDateShort(p.expiresAt) }}
                </div>
              </td>

              <!-- Üretim + Tali Acente -->
              <td class="py-2.5 px-3 hidden md:table-cell">
                <template v-if="!p.isEditable">
                  <span class="text-muted">{{ prodOptions.find(o => o.value === p.productionType)?.label || '-' }}</span>
                  <div v-if="p.branchName" class="text-muted mt-0.5">{{ p.branchName }}</div>
                </template>
                <template v-else>
                  <USelect
                    :model-value="p.productionType ?? undefined"
                    :items="prodOptions"
                    size="xs"
                    class="w-full"
                    @update:model-value="val => updateField(p, 'productionType', val)"
                  />
                  <USelectMenu
                    v-if="p.productionType !== 'SELF'"
                    :model-value="branchOptions.find(b => b.value === p.branchId)"
                    :items="branchOptions"
                    size="xs"
                    placeholder="Acente..."
                    searchable
                    :search-input="{ placeholder: 'Ara...' }"
                    class="w-full mt-1"
                    :ui="{ content: 'w-auto min-w-[200px]' }"
                    @update:model-value="val => updateField(p, 'branchId', val?.value)"
                  />
                </template>
              </td>

              <!-- Satış Yapan -->
              <td class="py-2.5 px-3 hidden md:table-cell">
                <span v-if="!p.isEditable || (p.soldByLocked && p.soldBy)" class="font-medium">{{ p.soldByName || '-' }}</span>
                <USelectMenu
                  v-else
                  :model-value="userOptions.find(u => u.value === p.soldBy)"
                  :items="userOptions"
                  size="xs"
                  class="w-full"
                  :class="!p.soldBy ? 'ring-1 ring-orange-400 rounded-lg' : ''"
                  placeholder="Seç..."
                  searchable
                  :search-input="{ placeholder: 'Ara...' }"
                  :ui="{ content: 'w-auto min-w-[200px]' }"
                  @update:model-value="val => updateField(p, 'soldBy', val?.value)"
                />
              </td>

              <!-- Prim -->
              <td class="py-2.5 px-3 text-right whitespace-nowrap">
                <div class="font-bold">{{ formatCurrency(p.grossPremium) }}</div>
                <div class="text-muted">{{ formatCurrency(p.netPremium) }}</div>
              </td>

              <!-- İş Türü -->
              <td class="py-2.5 px-3 hidden md:table-cell">
                <template v-if="p.isCancelled">
                  <span class="text-muted">—</span>
                </template>
                <template v-else>
                  <span v-if="!p.isEditable" class="text-muted">{{ p.businessType === 'NEW' ? 'Yeni İş' : p.businessType === 'RENEWAL' ? 'Yenileme' : '-' }}</span>
                  <USelect
                    v-else
                    :model-value="p.businessType ?? undefined"
                    :items="businessTypeOptions"
                    size="xs"
                    class="w-full"
                    :class="!p.businessType ? 'ring-1 ring-orange-400 rounded-lg' : ''"
                    placeholder="Seç..."
                    @update:model-value="val => { updateField(p, 'businessType', val); p.referenceSource = null; p.referenceSourceName = null }"
                  />
                </template>
              </td>

              <!-- Kaynak -->
              <td class="py-2.5 px-3 hidden md:table-cell">
                <template v-if="p.isCancelled">
                  <span class="text-muted">—</span>
                </template>
                <template v-else>
                  <span v-if="!p.isEditable" class="text-muted">{{ p.referenceSourceName || '-' }}</span>
                  <span v-else-if="!p.businessType" class="text-xs text-muted italic">Önce iş türü seçin</span>
                  <USelectMenu
                    v-else
                    :model-value="getRefOptionsForPolicy(p).find(r => r.value === p.referenceSource)"
                    :items="getRefOptionsForPolicy(p)"
                    size="xs"
                    class="w-full"
                    :class="!p.referenceSource ? 'ring-1 ring-orange-400 rounded-lg' : ''"
                    placeholder="Seç..."
                    searchable
                    :search-input="{ placeholder: 'Ara...' }"
                    :ui="{ content: 'w-auto min-w-[220px]' }"
                    @update:model-value="val => updateField(p, 'referenceSource', val?.value)"
                  />
                </template>
              </td>

              <!-- Durum -->
              <td class="py-2 px-2">
                <UBadge
                  :color="p.status === 'ACTIVE' ? 'success' : p.status === 'CANCELLED' ? 'error' : 'neutral'"
                  variant="soft"
                  size="sm"
                  class="whitespace-nowrap"
                >
                  {{ p.status === 'ACTIVE' ? 'Aktif' : p.status === 'CANCELLED' ? 'İptal' : 'Süresi Dolmuş' }}
                </UBadge>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </UCard>

    <!-- Sol alt bildirim -->
    <Teleport to="body">
      <Transition name="slide-up">
        <div v-if="localToast" class="fixed bottom-4 left-4 z-[100] max-w-sm">
          <div class="flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg border border-default text-sm"
            :class="localToast.color === 'error' ? 'bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300' : localToast.color === 'neutral' ? 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300' : 'bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300'">
            <UIcon :name="localToast.color === 'error' ? 'i-lucide-circle-x' : localToast.color === 'neutral' ? 'i-lucide-undo-2' : 'i-lucide-circle-check'" class="size-4 shrink-0" />
            <span class="font-medium">{{ localToast.title }}</span>
            <UButton v-if="localToast.action" :label="localToast.action.label" size="xs" color="neutral" variant="outline" class="ml-auto shrink-0" @click="localToast.action.onClick(); localToast = null" />
            <button v-else class="ml-auto text-current opacity-50 hover:opacity-100 shrink-0" @click="localToast = null"><UIcon name="i-lucide-x" class="size-3.5" /></button>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
const { get, put } = useApi()
const { user } = useAuth()
const isAdmin = computed(() => user.value?.role === 'admin')

// Sol alt bildirim
const localToast = ref<{ title: string; color: string; action?: { label: string; onClick: () => void } } | null>(null)
let localToastTimer: ReturnType<typeof setTimeout> | null = null
function showToast(opts: { title: string; color?: string; duration?: number; action?: { label: string; onClick: () => void } }) {
  if (localToastTimer) clearTimeout(localToastTimer)
  localToast.value = { title: opts.title, color: opts.color || 'success', action: opts.action }
  localToastTimer = setTimeout(() => { localToast.value = null }, opts.duration || 4000)
}

// --- State ---
const policies = ref<any[]>([])
const totalGross = ref(0)
const totalNet = ref(0)
const totalCommission = ref(0)
const missing = ref(0)
const loading = ref(false)

const today = new Date().toISOString().slice(0, 10)
const selectedDate = ref(today)
const filterSoldBy = ref<string | number>('all')

const users = ref<any[]>([])
const branches = ref<any[]>([])
const refSources = ref<any[]>([])

// --- Options ---
const userOptions = computed(() =>
  users.value.map(u => ({ label: u.name, value: u.id }))
)
const branchOptions = computed(() =>
  branches.value.map(b => ({ label: b.name, value: b.id }))
)
const businessTypeOptions = [
  { label: 'YENİ İŞ', value: 'NEW' },
  { label: 'YENİLEME', value: 'RENEWAL' },
]

function getRefOptionsForPolicy(policy: any) {
  const bt = policy.businessType
  if (!bt) return refSources.value.filter((r: any) => r.isActive).map((r: any) => ({ label: r.name, value: r.id }))
  if (bt === 'RENEWAL') {
    return refSources.value.filter((r: any) => r.isActive && (r.businessType === 'RENEWAL' || !r.businessType)).map((r: any) => ({ label: r.name, value: r.id }))
  }
  return refSources.value.filter((r: any) => r.isActive && (r.businessType === 'NEW' || !r.businessType)).map((r: any) => ({ label: r.name, value: r.id }))
}

const refOptions = computed(() =>
  refSources.value.filter((r: any) => r.isActive).map((r: any) => ({ label: r.name, value: r.id }))
)
const prodOptions = [
  { label: 'Acentem', value: 'SELF' },
  { label: 'Tali Gelen', value: 'INCOMING' },
  { label: 'Tali Giden', value: 'OUTGOING' },
]

// --- Fetch ---
async function fetch() {
  loading.value = true
  try {
    const q: Record<string, any> = { date: selectedDate.value }
    if (filterSoldBy.value !== 'all') q.soldBy = filterSoldBy.value
    const res = await get<any>('policies/daily', q)
    policies.value = res.data?.policies ?? []
    totalGross.value = res.data?.totalGross ?? 0
    totalNet.value = res.data?.totalNet ?? 0
    totalCommission.value = res.data?.totalCommission ?? 0
    missing.value = res.data?.missing ?? 0
  } catch (e: any) {
    showToast({ title: 'Yüklenemedi', color: 'error' })
  } finally {
    loading.value = false
  }
}

async function fetchDropdowns() {
  const [u, b, r] = await Promise.all([
    get<any>('users?dropdown=1'),
    get<any>('branches?all=1'),
    get<any>('reference-sources'),
  ])
  users.value = u.data || u || []
  branches.value = b.data || b || []
  refSources.value = r.data || r || []
}

// --- Inline edit ---
async function updateField(policy: any, field: string, value: any) {
  // Değişiklik öncesi tüm etkilenebilecek alanları kaydet
  const snapshot = {
    businessType:        policy.businessType,
    productionType:      policy.productionType,
    branchId:            policy.branchId,
    branchName:          policy.branchName,
    soldBy:              policy.soldBy,
    soldByName:          policy.soldByName,
    referenceSource:     policy.referenceSource,
    referenceSourceName: policy.referenceSourceName,
  }

  // Reaktif güncelle
  policy[field] = value
  if (field === 'soldBy') policy.soldByName = users.value.find(u => u.id === value)?.name ?? null
  if (field === 'branchId') policy.branchName = branches.value.find(b => b.id === value)?.name ?? null
  if (field === 'referenceSource') policy.referenceSourceName = refSources.value.find((r: any) => r.id === value)?.name ?? null
  if (field === 'productionType' && value === 'SELF') { policy.branchId = null; policy.branchName = null }
  if (field === 'businessType') { policy.referenceSource = null; policy.referenceSourceName = null }
  missing.value = policies.value.filter(p => !p.isCancelled && (!p.soldBy || !p.referenceSource || !p.businessType)).length

  // DB'ye gönderilecek veri (productionType SELF'e dönerse branchId de temizlenir)
  const payload: Record<string, any> = { [field]: value }
  if (field === 'productionType' && value === 'SELF') payload.branchId = null
  if (field === 'businessType') payload.referenceSource = null

  try {
    await put(`policies/${policy.id}`, payload)

    showToast({
      title: 'Kaydedildi',
      color: 'success',
      duration: 8000,
      action: {
        label: 'Geri Al',
        onClick: async () => {
          Object.assign(policy, snapshot)
          missing.value = policies.value.filter(p => !p.isCancelled && (!p.soldBy || !p.referenceSource || !p.businessType)).length

          const revertPayload: Record<string, any> = { [field]: snapshot[field as keyof typeof snapshot] }
          if (field === 'productionType') revertPayload.branchId = snapshot.branchId
          if (field === 'businessType') revertPayload.referenceSource = snapshot.referenceSource

          try {
            await put(`policies/${policy.id}`, revertPayload)
            showToast({ title: 'Geri alındı', color: 'neutral', duration: 3000 })
          } catch {
            policy[field] = value
            if (field === 'soldBy') policy.soldByName = users.value.find(u => u.id === value)?.name ?? null
            if (field === 'branchId') policy.branchName = branches.value.find(b => b.id === value)?.name ?? null
            if (field === 'referenceSource') policy.referenceSourceName = refSources.value.find(r => r.id === value)?.name ?? null
            if (field === 'productionType' && value === 'SELF') { policy.branchId = null; policy.branchName = null }
            missing.value = policies.value.filter(p => !p.isCancelled && (!p.soldBy || !p.referenceSource || !p.businessType)).length
            showToast({ title: 'Geri alma başarısız', color: 'error', duration: 4000 })
          }
        },
      },
    })
  } catch (e: any) {
    // Hata durumunda snapshot'tan geri yükle
    Object.assign(policy, snapshot)
    missing.value = policies.value.filter(p => !p.isCancelled && (!p.soldBy || !p.referenceSource || !p.businessType)).length
    showToast({ title: 'Güncelleme başarısız', color: 'error' })
  }
}

// --- Navigation ---
function prevDay() {
  const d = new Date(selectedDate.value)
  d.setDate(d.getDate() - 1)
  selectedDate.value = d.toISOString().slice(0, 10)
  fetch()
}
function nextDay() {
  const d = new Date(selectedDate.value)
  d.setDate(d.getDate() + 1)
  selectedDate.value = d.toISOString().slice(0, 10)
  fetch()
}
function goToday() {
  selectedDate.value = today
  fetch()
}

// --- Helpers ---
function isMissing(p: any) {
  return !p.soldBy || !p.referenceSource
}
function formatDate(d?: string) {
  if (!d) return '-'
  return new Date(d).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}
function formatDateShort(d?: string) {
  if (!d) return '-'
  return new Date(d).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit' })
}
function formatCurrency(v: number) {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v)
}
function getCustomerId(p: any) {
  return p.customerId ?? ''
}

// --- Init ---
onMounted(async () => {
  await fetchDropdowns()
  await fetch()
})
</script>

<style scoped>
.slide-up-enter-active, .slide-up-leave-active {
  transition: all 0.25s ease;
}
.slide-up-enter-from, .slide-up-leave-to {
  opacity: 0;
  transform: translateY(12px);
}
</style>
