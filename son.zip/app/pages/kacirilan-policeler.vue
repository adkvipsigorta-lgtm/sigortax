<script setup lang="ts">
definePageMeta({
  layout: 'default',
  middleware: 'auth'
})

useSeoMeta({ title: 'Kaçırılan Poliçeler' })

const { get, put, post } = useApi()
const { token } = useAuth()
const { can } = usePermissions()
const toast = useToast()

const loading = ref(true)
const statsLoading = ref(true)
const stats = ref<any>(null)
const items = ref<any[]>([])
const pagination = ref<any>(null)

// Filtreler
const tab = ref<'upcoming' | 'overdue'>('upcoming')
const range = ref('')
const branch = ref('')
const search = ref('')
const statusFilter = ref('')
const page = ref(1)

const statusOptions = [
  { value: '', label: 'Tümü' },
  { value: 'PENDING', label: 'Beklemede' },
  { value: 'WON', label: 'Kazanıldı (Son 12 ay)' },
  { value: 'VEHICLE_SOLD', label: 'İhtiyaç Duymuyor / Araç-Konut Satıldı' }
]

// Dropdown'da agent'in elle seçebileceği seçenekler (WON otomatik, elle seçilmez)
const manualStatusOptions = [
  { value: 'PENDING', label: 'Beklemede' },
  { value: 'VEHICLE_SOLD', label: 'İhtiyaç Duymuyor / Araç-Konut Satıldı' }
]

const statusLabels: Record<string, string> = {
  PENDING: 'Beklemede',
  WON: 'Kazanıldı',
  ABANDONED: 'İhtiyaç Duymuyor',
  VEHICLE_SOLD: 'İhtiyaç Duymuyor'
}

const statusIcons: Record<string, string> = {
  PENDING: 'i-lucide-clock',
  WON: 'i-lucide-check-circle',
  ABANDONED: 'i-lucide-ban',
  VEHICLE_SOLD: 'i-lucide-ban'
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
  WON: 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300',
  ABANDONED: 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300',
  VEHICLE_SOLD: 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300'
}

function formatPhone(phone?: string): string {
  if (!phone) return ''
  const digits = phone.replace(/\D/g, '')
  let local = digits
  if (local.startsWith('90') && local.length === 12) local = local.slice(2)
  else if (local.startsWith('0') && local.length === 11) local = local.slice(1)
  if (local.length !== 10) return phone
  return `+90 ${local.slice(0,3)} ${local.slice(3,6)} ${local.slice(6,8)} ${local.slice(8,10)}`
}

async function fetchStats() {
  statsLoading.value = true
  try {
    const res = await get('lost-policies/stats')
    stats.value = res.data
  } catch {
    stats.value = null
  } finally {
    statsLoading.value = false
  }
}

async function fetchItems() {
  loading.value = true
  try {
    const params: Record<string, string> = {
      tab: tab.value,
      page: String(page.value),
      limit: '50'
    }
    if (range.value) params.range = range.value
    if (branch.value) params.branch = branch.value
    if (search.value) params.search = search.value
    if (statusFilter.value) params.status = statusFilter.value

    const res = await get('lost-policies', params)
    const d = res.data || res
    items.value = d.items || []
    pagination.value = d.pagination || null
  } catch {
    items.value = []
  } finally {
    loading.value = false
  }
}

watch([tab, range, branch, statusFilter], () => {
  page.value = 1
  fetchItems()
})

watch(page, () => fetchItems())

let searchTimeout: ReturnType<typeof setTimeout> | null = null
watch(search, () => {
  if (searchTimeout) clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    page.value = 1
    fetchItems()
  }, 400)
})

onMounted(() => {
  fetchStats()
  fetchItems()
})

// Durum guncelle
async function updateStatus(policyId: number, newStatus: string) {
  // Aninda UI'dan kaldir
  if (['WON', 'ABANDONED', 'VEHICLE_SOLD'].includes(newStatus) && !statusFilter.value) {
    items.value = items.value.filter(i => i.id !== policyId)
  } else {
    const item = items.value.find(i => i.id === policyId)
    if (item) item.action_status = newStatus
  }
  try {
    await put(`lost-policies/${policyId}`, { status: newStatus })
  } catch {}
  fetchStats()
}

// Vade Değiştir modal
const vadeDegistirOpen = ref(false)
const vadeDegistirItem = ref<any>(null)
const newExpectedDate = ref('')
const vadeSaving = ref(false)

function openVadeDegistir(item: any) {
  vadeDegistirItem.value = item
  newExpectedDate.value = item.expected_date || item.estimated_renewal?.split('T')[0] || ''
  vadeDegistirOpen.value = true
}

async function saveVadeAndCreateTask() {
  if (!vadeDegistirItem.value || !newExpectedDate.value) return
  vadeSaving.value = true
  try {
    await put(`lost-policies/${vadeDegistirItem.value.id}`, { expectedDate: newExpectedDate.value })
    vadeDegistirItem.value.expected_date = newExpectedDate.value
    await post('tasks', {
      type: 'RENEWAL',
      policyId: vadeDegistirItem.value.id,
      expiresAtOverride: newExpectedDate.value
    })
    toast.add({ title: 'Vade güncellendi ve yenileme görevi oluşturuldu', color: 'success' })
    vadeDegistirOpen.value = false
    fetchStats()
  } catch (e: any) {
    toast.add({ title: e?.data?.message || e?.message || 'İşlem başarısız', color: 'error' })
  } finally {
    vadeSaving.value = false
  }
}

// Belge seri no guncelle - debounce ile
const regTimers: Record<number, ReturnType<typeof setTimeout>> = {}

function onRegNoInput(item: any, value: string) {
  item.current_registration_no = value
  if (regTimers[item.id]) clearTimeout(regTimers[item.id])
  regTimers[item.id] = setTimeout(async () => {
    try {
      await put(`lost-policies/${item.id}`, { registrationNo: value || null })
    } catch {}
  }, 600)
}

// Excel export
function exportExcel() {
  const params = new URLSearchParams({ tab: tab.value, token: token.value || '' })
  if (branch.value) params.set('branch', branch.value)
  if (search.value) params.set('search', search.value)
  if (statusFilter.value) params.set('status', statusFilter.value)
  window.open(`/api/lost-policies/export?${params.toString()}`, '_blank')
}


const legacyColorMap: Record<string, string> = {
  primary: '#3b82f6',
  error: '#ef4444',
  success: '#22c55e',
  warning: '#f59e0b',
  info: '#8b5cf6',
  neutral: '#6b7280'
}

function toHex(color?: string): string {
  if (!color) return '#3b82f6'
  if (color.startsWith('#')) return color
  return legacyColorMap[color] || '#3b82f6'
}

function formatCurrency(val: number) {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(val)
}

function formatDate(d: string) {
  if (!d) return '-'
  return new Date(d).toLocaleDateString('tr-TR')
}

function urgencyBadge(days: number) {
  if (days < 0) return { label: `${Math.abs(days)} gün geçti`, class: 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300', icon: 'i-lucide-alert-circle' }
  if (days === 0) return { label: 'Bugün', class: 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300', icon: 'i-lucide-alert-triangle' }
  if (days <= 7) return { label: `${days} gün`, class: 'bg-orange-100 text-orange-700 dark:bg-orange-900/50 dark:text-orange-300', icon: 'i-lucide-clock' }
  if (days <= 15) return { label: `${days} gün`, class: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-300', icon: 'i-lucide-clock' }
  return { label: `${days} gün`, class: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400', icon: 'i-lucide-clock' }
}

</script>

<template>
  <div class="p-4 sm:p-6 space-y-5">
    <!-- Baslik -->
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="p-2.5 rounded-xl bg-primary-100 dark:bg-primary-900/30">
          <UIcon name="i-lucide-user-x" class="text-primary-600 dark:text-primary-400 text-2xl" />
        </div>
        <div>
          <h1 class="text-xl font-bold text-gray-900 dark:text-white">Kaçırılan Poliçeler</h1>
          <p class="text-xs text-gray-500 dark:text-gray-400">Süresi dolup yenilenmeyen poliçelerin geri kazanım takibi</p>
        </div>
      </div>
      <UButton v-if="can('lost_policies.view')" icon="i-lucide-download" variant="outline" size="sm" class="hidden sm:flex" @click="exportExcel">
        Excel
      </UButton>
    </div>

    <!-- Ozet Kartlari -->
    <div class="hidden sm:grid grid-cols-2 lg:grid-cols-5 gap-3">
      <button @click="tab = 'upcoming'; range = 'week'; statusFilter = ''" class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex items-center gap-3 hover:shadow-md hover:border-orange-300 dark:hover:border-orange-700 transition-all cursor-pointer text-left">
        <div class="p-2 rounded-lg bg-orange-50 dark:bg-orange-900/20">
          <UIcon name="i-lucide-alert-triangle" class="text-orange-500 text-lg" />
        </div>
        <div>
          <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Bu Hafta</p>
          <p class="text-xl font-bold text-gray-900 dark:text-white">{{ statsLoading ? '...' : (stats?.thisWeek ?? 0) }}</p>
        </div>
      </button>

      <button @click="tab = 'upcoming'; range = 'month'; statusFilter = ''" class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex items-center gap-3 hover:shadow-md hover:border-blue-300 dark:hover:border-blue-700 transition-all cursor-pointer text-left">
        <div class="p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20">
          <UIcon name="i-lucide-calendar" class="text-blue-500 text-lg" />
        </div>
        <div>
          <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Bu Ay</p>
          <p class="text-xl font-bold text-gray-900 dark:text-white">{{ statsLoading ? '...' : (stats?.thisMonth ?? 0) }}</p>
        </div>
      </button>

      <button @click="tab = 'overdue'; range = ''; statusFilter = ''" class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex items-center gap-3 hover:shadow-md hover:border-red-300 dark:hover:border-red-700 transition-all cursor-pointer text-left">
        <div class="p-2 rounded-lg bg-red-50 dark:bg-red-900/20">
          <UIcon name="i-lucide-clock" class="text-red-500 text-lg" />
        </div>
        <div>
          <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Vadesi Geçmiş</p>
          <p class="text-xl font-bold text-gray-900 dark:text-white">{{ statsLoading ? '...' : (stats?.overdue ?? 0) }}</p>
        </div>
      </button>

      <button @click="tab = 'upcoming'; range = ''; statusFilter = 'WON'" class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex items-center gap-3 hover:shadow-md hover:border-green-300 dark:hover:border-green-700 transition-all cursor-pointer text-left">
        <div class="p-2 rounded-lg bg-green-50 dark:bg-green-900/20">
          <UIcon name="i-lucide-trophy" class="text-green-500 text-lg" />
        </div>
        <div>
          <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Geri Kazanılan</p>
          <p class="text-xl font-bold text-gray-900 dark:text-white">{{ statsLoading ? '...' : (stats?.won ?? 0) }}</p>
          <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">Son 12 ay</p>
        </div>
      </button>

      <button @click="tab = 'upcoming'; range = ''; statusFilter = 'VEHICLE_SOLD'" class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex items-center gap-3 hover:shadow-md hover:border-amber-300 dark:hover:border-amber-700 transition-all cursor-pointer text-left">
        <div class="p-2 rounded-lg bg-amber-50 dark:bg-amber-900/20">
          <UIcon name="i-lucide-ban" class="text-amber-500 text-lg" />
        </div>
        <div>
          <p class="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">İhtiyaç Duymuyor</p>
          <p class="text-xl font-bold text-gray-900 dark:text-white">{{ statsLoading ? '...' : (stats?.notNeeded ?? 0) }}</p>
        </div>
      </button>
    </div>

    <!-- Ana icerik -->
    <div class="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <!-- Sekmeler + Filtreler -->
      <div class="p-4 border-b border-gray-200 dark:border-gray-800">
        <div class="flex flex-col sm:flex-row sm:items-center gap-3">
          <!-- Sekmeler -->
          <div class="flex gap-1 bg-gray-100 dark:bg-gray-800 rounded-lg p-0.5 shrink-0">
            <button
              @click="tab = 'upcoming'; range = ''"
              :class="[
                'px-3.5 py-1.5 text-xs font-medium rounded-md transition-all',
                tab === 'upcoming'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              ]"
            >
              Aranacaklar
              <span v-if="stats?.thisMonth" class="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-primary-100 dark:bg-primary-900/50 text-primary-700 dark:text-primary-300">{{ stats.thisMonth }}</span>
            </button>
            <button
              @click="tab = 'overdue'; range = ''"
              :class="[
                'px-3.5 py-1.5 text-xs font-medium rounded-md transition-all',
                tab === 'overdue'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              ]"
            >
              Vadesi Geçenler
              <span v-if="stats?.overdue" class="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300">{{ stats.overdue }}</span>
            </button>
          </div>

          <!-- Filtreler -->
          <div class="hidden sm:flex flex-wrap gap-2 sm:ml-auto">
            <UInput
              v-model="search"
              placeholder="Müşteri, plaka, TC, poliçe no..."
              icon="i-lucide-search"
              size="sm"
              class="w-56"
            />
            <select
              v-model="branch"
              class="rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-xs px-2.5 py-1.5 text-gray-700 dark:text-gray-300"
            >
              <option value="">Tüm Branşlar</option>
              <option v-for="b in (stats?.branches || [])" :key="b.id" :value="b.id">
                {{ b.name }} ({{ b.cnt }})
              </option>
            </select>
            <select
              v-model="statusFilter"
              class="rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-xs px-2.5 py-1.5 text-gray-700 dark:text-gray-300"
            >
              <option v-for="s in statusOptions" :key="s.value" :value="s.value">{{ s.label }}</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Tablo -->
      <div class="overflow-x-auto">
        <div v-if="loading" class="p-16 text-center">
          <UIcon name="i-lucide-loader-2" class="animate-spin text-2xl text-primary-500" />
          <p class="mt-2 text-sm text-gray-500">Yükleniyor...</p>
        </div>

        <div v-else-if="items.length === 0" class="p-16 text-center">
          <div class="inline-flex p-4 rounded-full bg-gray-100 dark:bg-gray-800 mb-3">
            <UIcon name="i-lucide-inbox" class="text-3xl text-gray-400" />
          </div>
          <p class="text-sm text-gray-500">{{ tab === 'upcoming' ? 'Önümüzdeki 45 gün içinde aranacak kaçırılmış poliçe yok.' : 'Vadesi geçmiş kayıt bulunamadı.' }}</p>
        </div>

        <table v-else class="kp-table text-xs w-full table-fixed">
          <thead class="sticky top-0 z-10">
            <tr class="bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
              <th class="py-2 px-3 text-left text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 w-3/4 sm:w-[35%] lg:w-[20%]">Müşteri</th>
              <th class="hidden sm:table-cell py-2 px-3 text-left text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 sm:w-[12%] lg:w-[10%]">Branş</th>
              <th class="hidden md:table-cell py-2 px-3 text-left text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[9%]">Plaka / Ruhsat</th>
              <th class="hidden md:table-cell py-2 px-3 text-left text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[11%]">Son Poliçe</th>
              <th class="hidden md:table-cell py-2 px-3 text-left text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[10%]">Tahmini Vade</th>
              <th class="py-2 px-3 text-center text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 w-1/4 sm:w-[10%] lg:w-[8%]">Kalan</th>
              <th class="hidden md:table-cell py-2 px-3 text-right text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[9%]">Son Prim</th>
              <th class="hidden md:table-cell py-2 px-3 text-center text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[10%]">Durum</th>
              <th class="hidden md:table-cell py-2 px-3 text-center text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400 lg:w-[5%]">İşlem</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in items"
              :key="item.id"
              class="border-b border-default hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors"
            >
              <!-- Musteri -->
              <td class="px-3 py-2 align-middle">
                <div class="flex items-center gap-2 min-w-0">
                  <UPopover v-if="item.customer_phone">
                    <button class="text-muted hover:text-primary transition-colors shrink-0" :title="formatPhone(item.customer_phone)">
                      <UIcon name="i-lucide-phone" class="size-3.5" />
                    </button>
                    <template #content>
                      <div class="px-4 py-3 flex items-center gap-3">
                        <UIcon name="i-lucide-phone" class="size-4 text-primary" />
                        <span class="text-sm font-semibold tracking-wide">{{ formatPhone(item.customer_phone) }}</span>
                      </div>
                    </template>
                  </UPopover>
                  <div v-else class="size-3.5 shrink-0" />
                  <div class="min-w-0">
                    <NuxtLink :to="`/musteriler/${item.customer_id}`" class="font-semibold text-primary hover:underline block" :title="item.customer_name">
                      {{ item.customer_name }}
                    </NuxtLink>
                    <span v-if="item.customer_identity" class="text-muted block font-mono">{{ item.customer_identity }}</span>
                  </div>
                </div>
              </td>
              <!-- Brans -->
              <td class="px-3 py-2 whitespace-nowrap align-middle">
                <span
                  class="inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold"
                  :style="{
                    backgroundColor: toHex(item.branch_color) + '1a',
                    color: toHex(item.branch_color)
                  }"
                >
                  {{ item.branch_name }}
                </span>
              </td>
              <!-- Plaka / Ruhsat -->
              <td class="hidden md:table-cell px-3 py-2 whitespace-nowrap align-middle">
                <div v-if="item.plate_no" class="inline-flex flex-col w-full">
                  <span class="font-mono text-xs font-semibold bg-yellow-50 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 px-2 py-0.5 rounded border border-yellow-200 dark:border-yellow-800 text-center block">
                    {{ item.plate_no }}
                  </span>
                  <input
                    :value="item.current_registration_no || ''"
                    @input="onRegNoInput(item, ($event.target as HTMLInputElement).value)"
                    class="font-mono text-xs font-semibold text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded border border-gray-200 dark:border-gray-700 text-center block mt-1 w-full outline-none focus:ring-1 focus:ring-primary-400 focus:border-primary-400"
                    placeholder="Belge Seri No"
                  />
                </div>
                <span v-else class="text-gray-300 dark:text-gray-600">-</span>
              </td>
              <!-- Son Police -->
              <td class="hidden md:table-cell px-3 py-3" :title="item.policy_no">
                <span class="text-xs text-muted font-mono">{{ item.policy_no }}</span>
                <p v-if="item.company_name" class="text-xs text-muted mt-0.5">{{ item.company_name }}</p>
              </td>
              <!-- Tahmini Vade -->
              <td class="hidden md:table-cell px-3 py-2 whitespace-nowrap align-middle">
                <span class="text-xs font-semibold" :class="item.expected_date ? 'text-primary-600 dark:text-primary-400' : 'text-gray-500 dark:text-gray-400'">
                  {{ item.expected_date ? formatDate(item.expected_date) : (item.estimated_renewal ? formatDate(item.estimated_renewal) : '-') }}
                </span>
              </td>
              <!-- Kalan Gun -->
              <td class="px-3 py-2 text-center">
                <template v-if="item.action_status === 'WON'">
                  <div class="inline-flex flex-col items-center gap-0.5">
                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300">
                      <UIcon name="i-lucide-check-circle" class="text-[10px]" />
                      Kazanıldı
                    </span>
                    <span v-if="item.won_days_before != null && item.won_days_before >= 0" class="text-[10px] text-green-600 dark:text-green-400">
                      {{ item.won_days_before === 0 ? 'Vade günü' : `${item.won_days_before} gün kala` }}
                    </span>
                  </div>
                </template>
                <span v-else class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap" :class="urgencyBadge(item.remaining_days).class">
                  <UIcon :name="urgencyBadge(item.remaining_days).icon" class="text-xs" />
                  {{ urgencyBadge(item.remaining_days).label }}
                </span>
              </td>
              <!-- Prim -->
              <td class="hidden md:table-cell px-3 py-3 text-right whitespace-nowrap tabular-nums">
                <template v-if="item.action_status === 'WON' && item.new_premium">
                  <div class="text-[10px] text-muted line-through">{{ formatCurrency(item.gross_premium) }} TL</div>
                  <div class="text-xs font-semibold text-green-600 dark:text-green-400">{{ formatCurrency(item.new_premium) }} TL</div>
                </template>
                <template v-else>
                  <span class="font-semibold">{{ formatCurrency(item.gross_premium) }}</span>
                  <span class="text-xs text-muted ml-0.5">TL</span>
                </template>
              </td>
              <!-- Durum -->
              <td class="hidden md:table-cell px-3 py-2 text-center kp-no-clip">
                <UPopover v-model:open="item._statusOpen">
                  <button
                    :class="['inline-flex items-center gap-1.5 text-xs font-semibold rounded-full px-3 py-1 cursor-pointer transition-all hover:ring-2 hover:ring-offset-1 hover:ring-gray-300 dark:hover:ring-gray-600', statusColors[item.action_status || 'PENDING']]"
                  >
                    <UIcon :name="statusIcons[item.action_status || 'PENDING']" class="text-xs" />
                    {{ statusLabels[item.action_status || 'PENDING'] }}
                    <UIcon name="i-lucide-chevron-down" class="text-xs opacity-60" />
                  </button>
                  <template #content>
                    <div class="p-1.5 w-44">
                      <button
                        v-for="s in manualStatusOptions"
                        :key="s.value"
                        @click="updateStatus(item.id, s.value); item._statusOpen = false"
                        :class="[
                          'w-full flex items-center gap-2 px-2.5 py-2 rounded-md text-xs transition-colors',
                          (item.action_status || 'PENDING') === s.value
                            ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300 font-semibold'
                            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                        ]"
                      >
                        <span :class="['w-5 h-5 rounded-full flex items-center justify-center text-xs', statusColors[s.value]]">
                          <UIcon :name="statusIcons[s.value]" />
                        </span>
                        {{ s.label }}
                        <UIcon v-if="(item.action_status || 'PENDING') === s.value" name="i-lucide-check" class="ml-auto text-primary-500 text-xs" />
                      </button>
                    </div>
                  </template>
                </UPopover>
              </td>
              <!-- İşlem -->
              <td class="hidden md:table-cell px-3 py-2 text-center kp-no-clip">
                <UTooltip v-if="item.action_status !== 'WON'" text="Vade değiştir ve görev oluştur">
                  <button
                    @click="openVadeDegistir(item)"
                    class="inline-flex items-center justify-center w-8 h-8 rounded-lg transition-all bg-primary-50 text-primary-600 hover:bg-primary-100 dark:bg-primary-900/20 dark:text-primary-400 dark:hover:bg-primary-900/40"
                  >
                    <UIcon name="i-lucide-calendar-plus" class="text-base" />
                  </button>
                </UTooltip>
                <span v-else class="text-xs text-muted">—</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div v-if="pagination && pagination.totalPages > 1" class="px-3 py-3 border-t border-gray-200 dark:border-gray-800 flex items-center justify-between bg-gray-50/50 dark:bg-gray-800/20">
        <p class="text-xs text-gray-500">
          <span class="font-medium">{{ pagination.total }}</span> kayıt &middot; Sayfa {{ pagination.page }}/{{ pagination.totalPages }}
        </p>
        <div class="flex gap-1">
          <UButton
            size="xs"
            variant="outline"
            :disabled="page <= 1"
            @click="page--"
            icon="i-lucide-chevron-left"
          />
          <UButton
            size="xs"
            variant="outline"
            :disabled="page >= pagination.totalPages"
            @click="page++"
            icon="i-lucide-chevron-right"
          />
        </div>
      </div>
    </div>

    <!-- Vade Değiştir Modal -->
    <UModal :dismissible="false" v-model:open="vadeDegistirOpen" title="Vade Değiştir">
      <template #body>
        <div class="space-y-4">
          <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <p class="text-sm font-semibold">{{ vadeDegistirItem?.customer_name }}</p>
            <p class="text-xs text-muted mt-0.5">Mevcut bitiş tarihi: <span class="font-medium">{{ vadeDegistirItem ? formatDate(vadeDegistirItem.expires_at) : '' }}</span></p>
          </div>
          <UFormField label="Yeni Tahmini Vade Tarihi" hint="Müşterinin poliçeyi yenileme tarihi">
            <UInput type="date" v-model="newExpectedDate" class="w-full" />
          </UFormField>
          <p class="text-xs text-muted flex items-start gap-1.5">
            <UIcon name="i-lucide-info" class="shrink-0 mt-0.5" />
            Bu tarihe göre otomatik yenileme görevi oluşturulacak ve vadesi geldiğinde size hatırlatılacak.
          </p>
        </div>
      </template>
      <template #footer>
        <div class="flex justify-end gap-2">
          <UButton label="Vazgeç" color="neutral" variant="outline" @click="vadeDegistirOpen = false" />
          <UButton
            label="Kaydet ve Görev Oluştur"
            icon="i-lucide-calendar-plus"
            :loading="vadeSaving"
            :disabled="!newExpectedDate"
            @click="saveVadeAndCreateTask"
          />
        </div>
      </template>
    </UModal>

    <!-- Bilgi Kutusu -->
    <div class="bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/50 rounded-xl p-4">
      <div class="flex gap-3">
        <UIcon name="i-lucide-info" class="text-blue-500 text-base shrink-0 mt-0.5" />
        <div class="text-xs text-blue-700 dark:text-blue-400 space-y-1">
          <p class="font-semibold text-blue-800 dark:text-blue-300">Bu sayfa nasıl çalışır?</p>
          <ul class="list-disc list-inside space-y-0.5">
            <li>Vadesi geçmiş ve 45 gün içinde yenilenmeyen poliçeler bu listede otomatik olarak görünür. Sisteme yeni poliçe girildiğinde ilgili kayıt <strong>Kazanıldı</strong> olarak işaretlenir.</li>
            <li><strong>Tahmini Vade</strong> sütunu, poliçenin bitişinden 1 yıl sonrasını gösterir. Müşteri başka bir acentede yaptırmış olsa bile o tarihte tekrar vade gelmiş olacaktır. Tarihi elle de değiştirebilirsiniz.</li>
            <li><strong>İşlem</strong> sütunundaki takvim ikonuna tıklayarak yeni bir tahmini vade girebilir ve otomatik hatırlatma görevi oluşturabilirsiniz.</li>
            <li>Müşteriyi aradınız ve poliçeye ihtiyaç duymadığını öğrendiyseniz (araç sattı, konut sattı vb.) <strong>İhtiyaç Duymuyor</strong> seçeneğini işaretleyin — kayıt kalıcı olarak gizlenir.</li>
            <li>Liste her sayfa açılışında otomatik güncellenir; eski kayıtlar için Excel çıktısı alabilirsiniz.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.kp-table td {
  vertical-align: middle;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.kp-table th {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.kp-table td.kp-no-clip {
  overflow: visible;
  white-space: normal;
}
</style>
