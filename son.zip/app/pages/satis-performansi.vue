<script setup lang="ts">
definePageMeta({ layout: 'default', middleware: 'auth' })
useSeoMeta({ title: 'Aylık Satış Performansı' })

const { get } = useApi()
const { user } = useAuth()
const isAdmin = computed(() => user.value?.role === 'admin')

const loading = ref(false)
const policies = ref<any[]>([])
const stats = ref({ total: 0, new: 0, renewal: 0, totalGross: 0, totalNet: 0, cancelled: 0 })

const filterMonth = ref(new Date().getMonth() + 1)
const filterYear = ref(new Date().getFullYear())
const filterType = ref('all')
const filterInsurance = ref('all')
const filterSoldBy = ref('all')

const aylar = ['', 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık']
const monthLabel = computed(() => `${aylar[filterMonth.value]} ${filterYear.value}`)

function prevMonth() {
  if (filterMonth.value === 1) { filterMonth.value = 12; filterYear.value-- }
  else filterMonth.value--
  load()
}
function nextMonth() {
  if (filterMonth.value === 12) { filterMonth.value = 1; filterYear.value++ }
  else filterMonth.value++
  load()
}
function onSoldByChange() {
  load()
}

async function load() {
  loading.value = true
  try {
    const q: Record<string, any> = { month: filterMonth.value, year: filterYear.value }
    if (filterSoldBy.value && filterSoldBy.value !== 'all') q.soldBy = filterSoldBy.value
    const res = await get<any>('dashboard/sales-performance', q)
    const d = res?.data || {}
    stats.value = d.stats || { total: 0, new: 0, renewal: 0, totalGross: 0, totalNet: 0, cancelled: 0 }
    policies.value = d.policies || []
  } catch (e) {
    policies.value = []
  }
  loading.value = false
}

const users = ref<any[]>([])
const userOptions = computed(() => [
  { label: 'Tüm Temsilciler', value: 'all' },
  ...users.value.map((u: any) => ({ label: u.name, value: String(u.id) }))
])

const insuranceOptions = computed(() => {
  const s = new Set(policies.value.map((p: any) => p.insuranceName).filter(Boolean))
  return [...s].sort()
})

const filtered = computed(() => {
  let list = policies.value
  if (filterType.value === 'CANCELLED') list = list.filter((p: any) => p.isCancelled)
  else if (filterType.value && filterType.value !== 'all') list = list.filter((p: any) => !p.isCancelled && p.businessType === filterType.value)
  if (filterInsurance.value && filterInsurance.value !== 'all') list = list.filter((p: any) => p.insuranceName === filterInsurance.value)
  return list
})

const filteredGross = computed(() => filtered.value.reduce((s: number, p: any) => s + (p.grossPremium || 0), 0))

function fmt(val: number) {
  return val.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
function fmtDate(d: string) {
  if (!d) return '—'
  try { return new Date(d).toLocaleDateString('tr-TR') } catch { return d }
}
function shortName(name: string) {
  if (!name) return '—'
  const parts = name.trim().split(/\s+/)
  if (parts.length < 2) return name
  return parts[0][0] + '.' + parts.slice(1).join(' ')
}

onMounted(async () => {
  try { const r = await get<any>('users?dropdown=1'); users.value = r.data || [] } catch {}
  await load()
})
</script>

<template>
  <div class="space-y-5">
    <UCard>
      <template #header>
        <div class="flex flex-wrap items-center justify-between gap-3">
          <h3 class="font-semibold">Aylık Satış Performansı</h3>
        </div>
      </template>

      <!-- Loading -->
      <div v-if="loading" class="py-12 text-center text-muted">
        <UIcon name="i-lucide-loader-2" class="size-6 animate-spin" />
      </div>

      <div v-else>
        <!-- Kartlar -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-5">
          <div class="flex items-center gap-3 p-3 rounded-xl border border-default">
            <div class="size-10 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center shrink-0">
              <UIcon name="i-lucide-file-text" class="size-5 text-blue-600" />
            </div>
            <div>
              <p class="text-2xl font-bold">{{ stats.total }}</p>
              <p class="text-xs text-muted">Toplam Poliçe</p>
            </div>
          </div>
          <div class="flex items-center gap-3 p-3 rounded-xl border border-default">
            <div class="size-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <UIcon name="i-lucide-plus-circle" class="size-5 text-primary" />
            </div>
            <div>
              <p class="text-2xl font-bold text-primary">{{ stats.new }}</p>
              <p class="text-xs text-muted">Yeni İş</p>
            </div>
          </div>
          <div class="flex items-center gap-3 p-3 rounded-xl border border-default">
            <div class="size-10 rounded-lg bg-green-50 dark:bg-green-900/30 flex items-center justify-center shrink-0">
              <UIcon name="i-lucide-refresh-cw" class="size-5 text-green-600" />
            </div>
            <div>
              <p class="text-2xl font-bold text-green-600">{{ stats.renewal }}</p>
              <p class="text-xs text-muted">Yenileme</p>
            </div>
          </div>
          <div class="flex items-center gap-3 p-3 rounded-xl border border-default">
            <div class="size-10 rounded-lg bg-purple-50 dark:bg-purple-900/30 flex items-center justify-center shrink-0">
              <UIcon name="i-lucide-banknote" class="size-5 text-purple-600" />
            </div>
            <div>
              <p class="text-lg font-bold text-purple-600">{{ fmt(stats.totalGross) }}</p>
              <p class="text-xs text-muted">Brüt Prim</p>
            </div>
          </div>
          <div class="flex items-center gap-3 p-3 rounded-xl border border-default">
            <div class="size-10 rounded-lg bg-red-50 dark:bg-red-900/30 flex items-center justify-center shrink-0">
              <UIcon name="i-lucide-x-circle" class="size-5 text-red-500" />
            </div>
            <div>
              <p class="text-2xl font-bold text-red-500">{{ stats.cancelled }}</p>
              <p class="text-xs text-muted">İptal</p>
            </div>
          </div>
        </div>

        <!-- Filtreler -->
        <div class="flex items-center gap-2 mb-4">
          <div class="flex items-center gap-1 border border-[var(--ui-border)] rounded-[var(--ui-radius)] px-2 text-xs h-8">
            <UButton icon="i-lucide-chevron-left" size="xs" color="neutral" variant="ghost" @click="prevMonth" />
            <span class="font-medium min-w-[100px] text-center whitespace-nowrap">{{ monthLabel }}</span>
            <UButton icon="i-lucide-chevron-right" size="xs" color="neutral" variant="ghost" @click="nextMonth" />
          </div>
          <USelect v-if="isAdmin" v-model="filterSoldBy" :items="userOptions" size="xs" class="w-44" @update:model-value="onSoldByChange" />
          <USelect v-model="filterType" :items="[{ label: 'Tüm İş Türleri', value: 'all' }, { label: 'YENİ İŞ', value: 'NEW' }, { label: 'YENİLEME', value: 'RENEWAL' }, { label: 'İPTAL', value: 'CANCELLED' }]" size="xs" class="w-40" />
          <USelect v-if="insuranceOptions.length" v-model="filterInsurance" :items="[{ label: 'Tüm Branşlar', value: 'all' }, ...insuranceOptions.map(n => ({ label: n, value: n }))]" size="xs" class="w-40" />
          <UButton v-if="filterType !== 'all' || filterInsurance !== 'all' || filterSoldBy !== 'all'" icon="i-lucide-x" size="xs" color="neutral" variant="ghost" @click="filterType = 'all'; filterInsurance = 'all'; filterSoldBy = 'all'; onSoldByChange()" />
        </div>

        <!-- Tablo -->
        <div v-if="filtered.length" class="border border-default rounded-lg overflow-hidden">
          <table class="w-full text-xs table-fixed">
            <thead>
              <tr class="bg-gray-50 dark:bg-gray-800/50 border-b border-default">
                <th class="py-3 px-4 text-left font-semibold text-gray-500">Müşteri</th>
                <th class="hidden sm:table-cell py-3 px-4 text-left font-semibold text-gray-500">Branş</th>
                <th class="hidden lg:table-cell py-3 px-4 text-left font-semibold text-gray-500">Poliçe No</th>
                <th class="hidden md:table-cell py-3 px-4 text-left font-semibold text-gray-500">Plaka</th>
                <th class="py-3 px-4 text-left font-semibold text-gray-500">İş Türü</th>
                <th class="hidden lg:table-cell py-3 px-4 text-left font-semibold text-gray-500">Kaynak</th>
                <th class="py-3 px-4 text-right font-semibold text-gray-500">Brüt Prim</th>
                <th class="hidden sm:table-cell py-3 px-4 text-left font-semibold text-gray-500">Temsilci</th>
                <th class="hidden md:table-cell py-3 px-4 text-left font-semibold text-gray-500">Tarih</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="p in filtered" :key="p.id" class="border-b border-default last:border-0" :class="p.isCancelled ? 'bg-red-50/40 dark:bg-red-900/10' : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'">
                <td class="py-3 px-4 overflow-hidden">
                  <NuxtLink v-if="p.customerId" :to="`/musteriler/${p.customerId}`" class="font-semibold text-primary hover:underline block overflow-hidden whitespace-nowrap" style="text-overflow:clip" :title="p.customerName">{{ p.customerName }}</NuxtLink>
                  <span v-else class="font-semibold block overflow-hidden whitespace-nowrap" style="text-overflow:clip">{{ p.customerName || '—' }}</span>
                </td>
                <td class="hidden sm:table-cell py-3 px-4 font-medium overflow-hidden whitespace-nowrap" style="text-overflow:clip">{{ p.insuranceName || '—' }}</td>
                <td class="hidden lg:table-cell py-3 px-4 font-mono text-muted text-[11px]">{{ p.policyNo || '—' }}</td>
                <td class="hidden md:table-cell py-3 px-4 font-mono text-muted">{{ p.plateNo || '—' }}</td>
                <td class="py-3 px-4">
                  <UBadge v-if="p.isCancelled" color="error" variant="soft" size="sm" class="w-20 justify-center">İptal</UBadge>
                  <UBadge v-else-if="p.businessType" :color="p.businessType === 'NEW' ? 'primary' : 'success'" variant="soft" size="sm" class="w-20 justify-center">{{ p.businessType === 'NEW' ? 'Yeni İş' : 'Yenileme' }}</UBadge>
                  <span v-else class="text-muted">—</span>
                </td>
                <td class="hidden lg:table-cell py-3 px-4 text-muted">{{ p.referenceSourceName || '—' }}</td>
                <td class="py-3 px-4 text-right tabular-nums font-bold" :class="p.isCancelled ? 'text-red-500' : ''">{{ fmt(p.grossPremium) }}</td>
                <td class="hidden sm:table-cell py-3 px-4 text-muted whitespace-nowrap" :title="p.soldByName">{{ shortName(p.soldByName) }}</td>
                <td class="hidden md:table-cell py-3 px-4 text-muted tabular-nums">{{ fmtDate(p.issuedAt) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div v-else class="text-center py-10 text-muted text-sm">Bu dönemde poliçe bulunamadı</div>

        <!-- Alt Özet -->
        <div v-if="filtered.length" class="flex items-center justify-between mt-4 pt-3 border-t border-default">
          <p class="text-xs text-muted">{{ filtered.length }} poliçe</p>
          <p class="text-sm font-bold tabular-nums">{{ fmt(filteredGross) }} ₺</p>
        </div>
      </div>
    </UCard>
  </div>
</template>
