<script setup lang="ts">
import type { Branch } from '~/types'
import { z } from 'zod'

definePageMeta({
  layout: 'default',
  middleware: 'auth'
})

useSeoMeta({ title: 'Tali Acenteler' })

const toast = useToast()
const { post, put, del } = useApi()

// Server-side paginated data
const branches = usePaginatedData<Branch>({
  endpoint: 'branches',
  defaultLimit: 50,
  defaultSort: 'name',
  defaultOrder: 'asc'
})

onMounted(() => branches.fetchData())

// Search
const searchInput = ref('')
let searchTimeout: ReturnType<typeof setTimeout> | null = null
watch(searchInput, (val) => {
  if (searchTimeout) clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    branches.setSearch(val)
  }, 400)
})

// Sorting
const sortKeyMap: Record<string, string> = {
  name: 'name',
  commissionRate: 'commission_rate',
  createdAt: 'created_at'
}

const sorting = ref<{ id: string, desc: boolean }[]>([])
watch(sorting, (val) => {
  if (val.length) {
    const apiKey = sortKeyMap[val[0].id] || val[0].id
    branches.setSort(apiKey, val[0].desc ? 'desc' : 'asc')
  } else {
    branches.setSort('name', 'asc')
  }
}, { deep: true })

// Tablo
const columns = [
  { accessorKey: 'name', header: 'Acente Adı', enableSorting: true },
  { accessorKey: 'phone', header: 'Telefon', enableSorting: false },
  { accessorKey: 'commissionRate', header: 'Komisyon', enableSorting: true },
  { accessorKey: 'iban', header: 'IBAN', enableSorting: false },
  { accessorKey: 'isActive', header: 'Durum', enableSorting: false },
  { accessorKey: 'actions', header: '', enableSorting: false }
]

async function toggleActive(branch: any) {
  try {
    await put(`branches/${branch.id}`, { isActive: !branch.isActive })
    branch.isActive = !branch.isActive
    toast.add({ title: branch.isActive ? 'Acente aktif edildi' : 'Acente pasif edildi', color: 'success' })
  } catch {
    toast.add({ title: 'Durum değiştirilemedi', color: 'error' })
  }
}

// Modal
const isModalOpen = ref(false)
const isDeleteModalOpen = ref(false)
const editingBranch = ref<Branch | null>(null)
const deletingBranchId = ref<number | null>(null)

const branchSchema = z.object({
  name: z.string().min(2, 'Acente adı en az 2 karakter olmalıdir'),
  commissionRate: z.number().min(0, 'Komisyon 0\'dan kucuk olamaz').max(100, 'Komisyon 100\'den buyuk olamaz'),
  phone: z.string().optional().or(z.literal('')),
  iban: z.string().optional().or(z.literal(''))
})

const defaultForm = {
  name: '',
  commissionRate: 0,
  phone: '',
  iban: '',
  aliases: [] as string[]
}

const form = ref({ ...defaultForm })
const newAlias = ref('')

function addAlias() {
  const val = newAlias.value.trim().toUpperCase()
  if (!val) return
  if (form.value.aliases.includes(val)) {
    toast.add({ title: 'Bu isim zaten ekli', color: 'warning' })
    return
  }
  form.value.aliases.push(val)
  newAlias.value = ''
}

function removeAlias(index: number) {
  form.value.aliases.splice(index, 1)
}

// IBAN formatlama
function formatIban(value: string) {
  const clean = value.replace(/\s/g, '')
  return clean.match(/.{1,4}/g)?.join(' ') || clean
}

watch(() => form.value.iban, (val) => {
  if (val) {
    const formatted = formatIban(val)
    if (formatted !== val) form.value.iban = formatted
  }
})

function openAddModal() {
  editingBranch.value = null
  form.value = { ...defaultForm, aliases: [] }
  newAlias.value = ''
  isModalOpen.value = true
}

function openEditModal(branch: any) {
  editingBranch.value = branch
  form.value = {
    name: branch.name,
    commissionRate: branch.commissionRate,
    phone: branch.phone || '',
    iban: branch.iban || '',
    aliases: [...(branch.aliases || [])]
  }
  newAlias.value = ''
  isModalOpen.value = true
}

const savingBranch = ref(false)

async function saveBranch() {
  if (savingBranch.value) return
  savingBranch.value = true
  try {
    const payload: Record<string, any> = {
      name: form.value.name,
      commissionRate: form.value.commissionRate,
      phone: form.value.phone || null,
      iban: form.value.iban?.replace(/\s/g, '') || null,
      aliases: form.value.aliases.length > 0 ? form.value.aliases : []
    }

    if (editingBranch.value) {
      await put(`branches/${editingBranch.value.id}`, payload)
      toast.add({ title: 'Acente güncellendi', color: 'success' })
    } else {
      await post('branches', payload)
      toast.add({ title: 'Yeni acente eklendi', color: 'success' })
    }
    isModalOpen.value = false
    branches.refresh()
  } catch (error: any) {
    toast.add({ title: error.message || 'İşlem başarısız', color: 'error' })
  }
  savingBranch.value = false
}

function confirmDelete(id: number) {
  deletingBranchId.value = id
  isDeleteModalOpen.value = true
}

async function doDelete() {
  if (!deletingBranchId.value) return
  try {
    await del(`branches/${deletingBranchId.value}`)
    toast.add({ title: 'Acente silindi', color: 'success' })
    branches.refresh()
  } catch {
    toast.add({ title: 'Acente silinemedi', color: 'error' })
  }
  isDeleteModalOpen.value = false
  deletingBranchId.value = null
}

function getRowActions(branch: Branch) {
  return [
    [{ label: 'Düzenle', icon: 'i-lucide-pencil', onSelect: () => openEditModal(branch) }],
    [{ label: 'Sil', icon: 'i-lucide-trash-2', color: 'error' as const, onSelect: () => confirmDelete(branch.id) }]
  ]
}
</script>

<template>
  <div class="space-y-4">
    <UCard :ui="{ body: 'p-4' }">
      <!-- Header -->
      <template #header>
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <UInput
            v-model="searchInput"
            icon="i-lucide-search"
            placeholder="Acente ara..."
            class="w-full sm:w-64"
          />

          <div class="flex items-center gap-2">
            <UButton
              label="Yeni Acente"
              icon="i-lucide-plus"
              @click="openAddModal"
            />
          </div>
        </div>
      </template>

      <SkeletonTable v-if="branches.loading.value && !branches.data.value.length" :rows="6" :cols="5" />
      <div v-else class="border border-default rounded-lg overflow-x-auto">
        <UTable
          v-model:sorting="sorting"
          :data="branches.data.value"
          :columns="columns"
          :loading="branches.loading.value && !branches.data.value.length"
          :sorting-options="{ manualSorting: true }"
          :ui="{
            thead: 'bg-gray-50 dark:bg-gray-800/50',
            th: 'py-3 px-4 text-xs font-semibold tracking-wide text-gray-500 dark:text-gray-400',
            td: 'py-3 px-4'
          }"
        >
          <template #name-header="{ column }">
            <SortableHeader label="Acente Adı" :column="column" />
          </template>
          <template #commissionRate-header="{ column }">
            <SortableHeader label="Komisyon" :column="column" />
          </template>

          <template #name-cell="{ row }">
            <NuxtLink :to="`/settings/acenteler/${row.original.id}`" class="flex items-center gap-2.5 cursor-pointer hover:opacity-80">
              <div class="size-8 rounded-lg flex items-center justify-center shrink-0" :class="row.original.isActive ? 'bg-primary/10' : 'bg-gray-100 dark:bg-gray-800'">
                <UIcon name="i-lucide-building-2" class="size-4" :class="row.original.isActive ? 'text-primary' : 'text-muted'" />
              </div>
              <span class="text-sm font-semibold hover:underline" :class="row.original.isActive ? 'text-primary' : 'text-muted'">{{ row.original.name }}</span>
            </NuxtLink>
          </template>

          <template #phone-cell="{ row }">
            <a v-if="row.original.phone" :href="`tel:${row.original.phone}`" class="text-sm text-primary hover:underline inline-flex items-center gap-1.5">
              <UIcon name="i-lucide-phone" class="size-3.5" />
              {{ row.original.phone }}
            </a>
            <span v-else class="text-sm text-muted">—</span>
          </template>

          <template #commissionRate-cell="{ row }">
            <span class="text-sm font-medium tabular-nums">%{{ row.original.commissionRate }}</span>
          </template>

          <template #iban-cell="{ row }">
            <span v-if="row.original.iban" class="text-xs font-mono text-muted">{{ formatIban(row.original.iban) }}</span>
            <span v-else class="text-sm text-muted">—</span>
          </template>

          <template #isActive-cell="{ row }">
            <USwitch :model-value="row.original.isActive" @update:model-value="toggleActive(row.original)" />
          </template>

          <template #actions-cell="{ row }">
            <UDropdownMenu :items="getRowActions(row.original)">
              <UButton icon="i-lucide-ellipsis-vertical" color="neutral" variant="ghost" size="xs" />
            </UDropdownMenu>
          </template>
        </UTable>
      </div>

      <div class="h-[2px] w-full overflow-hidden">
        <div v-if="branches.loading.value" class="h-full bg-primary nav-loading-bar" />
      </div>

      <!-- Pagination -->
      <div class="flex flex-col sm:flex-row items-center gap-2 py-3 sm:justify-between">
        <div class="flex items-center gap-2 text-muted">
          <span class="hidden sm:inline text-sm">Sayfa başına satır</span>
          <USelect
            :model-value="branches.limit.value"
            :items="[{ label: '10', value: 10 }, { label: '15', value: 15 }, { label: '25', value: 25 }, { label: '50', value: 50 }]"
            value-key="value"
            size="xs"
            class="w-16"
            @update:model-value="(v: any) => { branches.limit.value = v; branches.setPage(1) }"
          />
          <span class="text-xs sm:text-sm">{{ (branches.page.value - 1) * branches.limit.value + 1 }} - {{ Math.min(branches.page.value * branches.limit.value, branches.total.value) }} / {{ branches.total.value }}</span>
        </div>

        <div class="flex items-center gap-2 sm:hidden">
          <UButton icon="i-lucide-chevron-left" size="xs" color="neutral" variant="ghost" :disabled="branches.page.value <= 1" @click="branches.setPage(branches.page.value - 1)" />
          <span class="text-xs text-muted whitespace-nowrap">{{ branches.page.value }} / {{ Math.ceil(branches.total.value / branches.limit.value) }}</span>
          <UButton icon="i-lucide-chevron-right" size="xs" color="neutral" variant="ghost" :disabled="branches.page.value >= Math.ceil(branches.total.value / branches.limit.value)" @click="branches.setPage(branches.page.value + 1)" />
        </div>
        <UPagination
          v-if="branches.total.value > branches.limit.value"
          class="hidden sm:flex"
          :default-page="branches.page.value"
          :items-per-page="branches.limit.value"
          :total="branches.total.value"
          @update:page="branches.setPage"
        />
      </div>
    </UCard>

    <!-- Ekle/Düzenle Modal -->
    <UModal :dismissible="false" v-model:open="isModalOpen" :title="editingBranch ? 'Acente Düzenle' : 'Yeni Acente'" class="sm:max-w-lg">
      <template #body>
        <UForm :schema="branchSchema" :state="form" @submit="saveBranch" class="space-y-5">
          <!-- Acente Bilgileri -->
          <div class="space-y-4">
            <UFormField label="Acente Adi" name="name" required>
              <UInput v-model="form.name" placeholder="Acente adı" icon="i-lucide-building" class="w-full" />
            </UFormField>

            <div class="grid grid-cols-2 gap-4">
              <UFormField label="Komisyon (%)" name="commissionRate" required>
                <UInput v-model.number="form.commissionRate" type="number" :min="0" :max="100" placeholder="0" icon="i-lucide-percent" class="w-full" />
              </UFormField>

              <UFormField label="Telefon" name="phone">
                <UInput v-model="form.phone" placeholder="+90 5XX XXX XX XX" icon="i-lucide-phone" class="w-full" />
              </UFormField>
            </div>
          </div>

          <USeparator />

          <!-- Banka Bilgileri -->
          <div>
            <h4 class="font-medium text-sm mb-3">Banka Bilgileri</h4>
            <UFormField label="IBAN" name="iban">
              <UInput v-model="form.iban" placeholder="TR00 0000 0000 0000 0000 0000 00" icon="i-lucide-landmark" class="w-full font-mono" maxlength="32" />
            </UFormField>
          </div>

          <USeparator />

          <!-- Alt Şirketler / Resmi Unvanlar -->
          <div>
            <h4 class="font-medium text-sm mb-2">Alt Şirketler / Resmi Unvanlar</h4>
            <p class="text-xs text-muted mb-3">PDF'deki acente adı bu isimlerden biriyle eşleşirse otomatik olarak bu acente seçilir.</p>

            <!-- Eklenen isimler -->
            <div v-if="form.aliases.length > 0" class="space-y-1.5 mb-3">
              <div
                v-for="(alias, i) in form.aliases"
                :key="i"
                class="flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-default"
              >
                <UIcon name="i-lucide-building" class="size-3.5 text-muted shrink-0" />
                <span class="text-sm flex-1 truncate">{{ alias }}</span>
                <UButton icon="i-lucide-x" size="xs" color="error" variant="ghost" @click="removeAlias(i)" />
              </div>
            </div>

            <!-- Yeni isim ekleme -->
            <div class="flex gap-2">
              <UInput
                v-model="newAlias"
                placeholder="Resmi unvan / alt şirket adı"
                icon="i-lucide-plus-circle"
                class="flex-1"
                size="sm"
                @keydown.enter.prevent="addAlias"
              />
              <UButton label="Ekle" size="sm" color="neutral" variant="outline" :disabled="!newAlias.trim()" @click="addAlias" />
            </div>
          </div>

          <USeparator />

          <div class="flex justify-end gap-2">
            <UButton label="İptal" color="neutral" variant="outline" :disabled="savingBranch" @click="isModalOpen = false" />
            <UButton :label="editingBranch ? 'Güncelle' : 'Kaydet'" icon="i-lucide-check" type="submit" :loading="savingBranch" :disabled="savingBranch" />
          </div>
        </UForm>
      </template>
    </UModal>

    <!-- Silme Onay -->
    <UModal :dismissible="false" v-model:open="isDeleteModalOpen" title="Acente Sil">
      <template #body>
        <div class="flex items-start gap-3">
          <div class="size-10 rounded-full bg-error/10 flex items-center justify-center shrink-0">
            <UIcon name="i-lucide-triangle-alert" class="size-5 text-error" />
          </div>
          <div>
            <p class="font-medium">Bu acenteyi silmek istediginize emin misiniz?</p>
            <p class="text-sm text-muted mt-1">Bu islem geri alinamaz. Acenteye ait poliçeler etkilenmez.</p>
          </div>
        </div>
      </template>
      <template #footer>
        <div class="flex justify-end gap-2">
          <UButton label="Vazgeç" color="neutral" variant="outline" @click="isDeleteModalOpen = false" />
          <UButton label="Sil" color="error" icon="i-lucide-trash-2" @click="doDelete" />
        </div>
      </template>
    </UModal>
  </div>
</template>

<style scoped>
@media (max-width: 767px) {
  :deep(table th:nth-child(4)),
  :deep(table td:nth-child(4)) { display: none; }
}
</style>
